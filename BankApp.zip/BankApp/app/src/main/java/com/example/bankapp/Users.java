package com.example.bankapp;

public class Users {



    //ArrayList<String> userList =  new ArrayList<String>();


    //intergers
    int age;
    int Sin;
    int userId;


    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getAccbal() {
        return accbal;
    }

    public void setAccbal(int accbal) {
        this.accbal = accbal;
    }

    int accbal;
    //strings
    String userName;
    String address;
    String Name;
    String password;




    public Users(int age, int sin, int userId, int accbal, String userName, String address, String name, String password) {
        this.age = age;
        Sin = sin;
        this.userId = userId;
        this.accbal = accbal;
        this.userName = userName;
        this.address = address;
        Name = name;
        this.password = password;
    }


    // int getter setters

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getSin() {
        return Sin;
    }

    public void setSin(int sin) {
        Sin = sin;
    }

    public int getUserId() { return userId; }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


    //String getter setter

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }


}

