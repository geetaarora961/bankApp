package com.example.bankapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    public static Users newuser[] = new Users[3];

    Button login;
    EditText userName, password;
    public static  String customername;
    public static  Integer customerbalance;
    public static int userIndex;
    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        login = findViewById(R.id.loginBtn);
        userName = findViewById(R.id.userName);
        password = findViewById(R.id.password);

        newuser[0] = new Users(18, 18445,0,1200,"Nimit96", "2901 kipligavenue", "Nimit","hello");
        newuser[1] = new Users(23, 18445,1,1400, "parimal97", "2901 kipligavenue", "Parimal","hello2");
        newuser[2] = new Users(22, 18445,2,1600,"geeta93", "2901 kipligavenue", "Geeta","hello3");
    }


    public  void loginIn(View view) {


        String userEntry = userName.getText().toString(); //username sent
        String passEntry = password.getText().toString(); //password sent

        int userid = searchUser(newuser, userEntry, passEntry);

        System.out.println(userid);

        if (userid == -1) {

            Toast.makeText(getApplicationContext(), "error 404 user not found", Toast.LENGTH_LONG).show();

        } else {

            int i = userdetails(newuser,userid);

            userIndex=i;

            customername  = newuser[userIndex].getName();

            customerbalance  = newuser[userIndex].getAccbal();
            Toast.makeText(getApplicationContext(), "code 200 user found", Toast.LENGTH_LONG).show();
            Intent loggedIn = new Intent(getApplicationContext(), SelectAcc.class);
            startActivity(loggedIn);

        }
    }


    public static  int  searchUser(Users newuser[], String user, String password) {

        int id;

        for (int i = 0; i < newuser.length; i++)

            if (user.equals(newuser[i].getUserName()) && password.equals(newuser[i].getPassword())) {
                id = newuser[i].getUserId();
                return id;
            }
        return -1;
    }


    public  static int userdetails(Users newuser[],int id){
        for(int i=0;i<newuser.length;i++)
            if(newuser[i].getUserId() == id)
             return id;
             return -1;
            }



}







