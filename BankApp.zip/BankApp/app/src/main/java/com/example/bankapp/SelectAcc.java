package com.example.bankapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class SelectAcc extends AppCompatActivity  implements AdapterView.OnItemSelectedListener{

Spinner sp;
   // Button saving,checking,transfer,paybills;

    TextView welcomebanner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_acc);

        List<String> AccountList = new ArrayList<String>();
        AccountList.add("Saving");
        AccountList.add("Chequing");
        AccountList.add("Transfer");
        AccountList.add("PayBills");

        sp= findViewById(R.id.coursespinner);


        ArrayAdapter<String> jobAdapter = new ArrayAdapter<String>(this, R.layout.support_simple_spinner_dropdown_item, AccountList);

        //make the dropdown style
        jobAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);

        //fill the spiner with the adapter items
        sp.setAdapter(jobAdapter);

        // to click on dropdown list
        sp.setOnItemSelectedListener(this);



//        saving = findViewById(R.id.saving);
//        checking = findViewById(R.id.checking);
//        transfer = findViewById(R.id.transfer);
//        paybills = findViewById(R.id.payBills);

        welcomebanner = findViewById(R.id.welcomeBanner);

        welcomebanner.setText("HI "+MainActivity.customername+" please select the folloing");



    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
